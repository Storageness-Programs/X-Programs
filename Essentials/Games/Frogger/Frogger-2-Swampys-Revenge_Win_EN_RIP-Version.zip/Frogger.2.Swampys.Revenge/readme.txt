Frogger 2 - Swampy's Revenge
****************************

Designed and Developed by Blitz Games
Published by Hasbro Interactive

Readme File
28 August, 2000
US English Version 0.02


Contents
********

    Quick Start Guide and Default Controls
1.  Processors Successfully Tested & Supported
2.  Supported Video Cards
3.  Known Video Card Problems
4.  Obtaining Video Card Drivers
5.  3D Performance
6.  Changing Video Card Options
7.  Networked Play
8.  Amendments
9.  Technical Support
10. License Agreement


Quick Start Guide & Default Controls
************************************

   How to play Frogger 2

The object of Frogger 2 is to collect the baby frogs scattered around the
widely varying worlds. When all the babies in a level are collected,
Frogger can move to the next level. 

Collect coins for added bonuses.

Slurp up sparkly flies for power ups!


Single Player
-------------

Cursors / joypad        Move Frogger! 
Enter or button A       Superhop in the direction Frogger is facing. Jump to
                        places a normal hop won't take you... 
                        Hit again to double-jump - Jump over enemies! 
Right Shift or button B Use your tongue to collect items
Right Ctrl or button C  Croak! The nearest baby frog will reply, helping you
                        to find it 
Escape                  Pause the game 

Multiplayer Controls
--------------------

Player2:
Q 		- up
A 		- down
S 		- left
D 		- right
Tab		- superhop

Player3:
8 		- up
I 		- down
O 		- left
P 		- right
7 		- superhop

Player4:
numpad-5 	- up
numpad-2 	- down
numpad-1 	- left
numpad-3 	- right
numpad-Enter 	- superhop



1. Processors Successfully Tested & Supported
*********************************************

Intel Pentium with MMX
Intel Pentium II
Intel Pentium III
Intel Celeron
AMD K6-2 3DNow! (via DirectX7)
AMD K6-3 3DNow! (via DirectX7)
AMD K7/Athlon 3DNow! (via DirectX7)


2. Supported Video Cards
************************

The following video cards have been successfully tested.
However, Frogger2 requires that the latest video drivers are used.
These are available from your hardware manufacturer.
Please see "Obtaining Video Card Drivers" for details

3DFX Voodoo Banshee
3DFX Voodoo
3DFX Voodoo 2
3DFX Voodoo 3

ATi 3D Rage II
ATi XPERT 98 AGP
ATi Rage Pro
ATi Rage Pro Turbo

Cirrus Logic GD-5464

Creative Exxtreme Permedia2

Diamond Stealth 64
Diamond Viper II
Diamond Viper 330 / 550
Diamond Hercules Beast

Matrox Millenium II
Matrox G100
Matrox G200
Matrox G400

Nvidia TNT
Nvidia TNT 2 / Ultra
Nvidia GeForce256
Nvidia GeForce2 GTS

S3 Trio
S3 Virge DX
S3 Vision
S3 Savage 3D

STB Velocity

Trident 3D Image 9750


3. Known Video Cards Problems
*****************************

If your card and problem appear in this list, try the proposed solution. Details
on how to do this can be found in "Changing Video Card Options."


ATi Rage Fury Maxx:
	Screen corruption may be evident at resolutions over 320x240 in fullscreen 
	software modes, and at any resolution in software windowed modes.
    Solution:
	Run in hardware mode or full-screen software mode at 640x480 resolution

ATi Rage 128 / Magnum 128:
	Screen corruption is likely in software windowed modes.
    Solution:
	Run in hardware mode, or full-screen software mode

Creative Exxtreme Permedia 2:
	Per-vertex alpha-ed polygons are not supported. Similarly, some pixel formats 
	are unsupported so many effects will not appear correctly.
    Solution:
	None for hardware mode. You may prefer software mode.

Diamond Monster Fusion:
	Screen corruption is likely in software windowed modes.
    Solution:
	Run in hardware mode, or full-screen software mode

Matrox M3D / PowerVR:
	There may be severe visual artifacts when running the game in hardware 
	accelerated mode using this card. Colorkeying is non-functional, so black or 
	magenta outlines may be visible. Additive or subtractive alpha modes are not 
	supported so many effects, water and glass may not display properly. Per-vertex
	alpha and gouraud value support and DirectX z-buffering occasionally fails to 
	work correctly.

	Note: Using this card in addition to another hardware accelerator will result in
	this card replacing the accelerator device in the list of selectable devices. This
	is a feature of the hardware.
    Solution:
	Run in software mode

Matrox Productiva G100:
	Translucent surfaces will appear pixellated due to the use of stipple alpha.
	Running in hardware windowed mode may result in drastically reduced performance.
    Solution:
	Run in full-screen hardware mode, or you may prefer software mode

Matrox Millenium / Mystique:
	Translucent surfaces will appear pixellated due to the use of stipple alpha.
    Solution:
	None for hardware mode. You may prefer software mode.

VideoLogic Neon 250 PowerVR2:
	Some polygons may incorrectly appear in front of others because of the depth 
	sort method used on this card.
    Solution:
	None for hardware mode. You may prefer software mode.


4. Obtaining Video Card Drivers
*******************************

You can download these drivers from the Internet. If you are experiencing
problems with Frogger2, look for your video card below to find the Web
address where you can download the appropriate drivers.

If none are available, try using the reference drivers for your graphics chipset.


Creative
   http://support.soundblaster.com/files/download.asp

Guillemot
   http://www.guillemot.com/

Matrox
   http://www.matrox.com/mga/drivers/latest_drivers/home.htm

ATI
   http://support.atitech.ca/drivers/drivers.html

Orchid
   http://www.orchid.com/support/driverlist.html

Diamond
   http://www.diamondmm.com/

PowerVR
   http://www.videologic.com/

3Dfx
   http://www.3dfxgamers.com/

NVidia
   http://www.nvidia.com/


5. 3D Performance
*****************

There are several possible causes of unsatisfactory video performance

a:  Check your system specification. Systems slower than a P200 MMX may run
    quite slowly.

b:  If you have a dedicated 3D card then ensure that you are using it. See "Changing
    Video Card Options" for details.
    (in some instances 3d cards will run more slowly than software. In this
    case try running in software to see if you prefer this)

c:  The default screen resolution for Frogger2 is 640x480. If you have a fast PC 
    then selecting a higher resolution will give improved visual quality at the
    expense of some speed. If you find that the game runs too slowly, try selecting
    a lower resolution. See "Changing Video Card Options" for details

d:  Outdated or incorrect drivers can also result in slow video performance. Visit
    your graphics card manufacturer's website for the latest drivers for your card.
    See "Obtaining Video Card Drivers" for details


6. Changing Video Card Options
******************************

Running the game full screen
----------------------------

1) Run "Reconfigure Frogger" from the start menu
2) Ensure that the "Run Windowed" box is unchecked
3) Select ok


Running the game using Hardware
-------------------------------

1) Run "Reconfigure Frogger" from the start menu
2) Select something other than "Software Rendering" from the Video Device list
3) Select ok

* you may have no listings other than "Software Rendering" in the Video Device list.
This may mean that you do not have a 3d Hardware Card installed in your machine.
If you are certain that you do have a 3d hardware card installed, you should install
the latest drivers. If this still does not work you should contact your hardware
manufacturer.

* you may have several entries in the Video Device windows. In this instance
follow the procedure above and test each one in turn, and use the one that
performs best.


Running the game using Software
-------------------------------

1) Run "Reconfigure Frogger" from the start menu
2) Select "Software Rendering" from the Video Device list
3) Select ok


7. Networked Play
*****************

Please check the following web site for updates
	http://www.frogger.com


8. Amendments & Additions
*************************

None as of 28 August 2000


9. Technical Support
********************

If you are having technical difficulties with the Frogger2 CD-ROM game, please
consult this README.TXT file before calling technical support. If you call
technical support, please have the following information available (and be
ready to take notes):

	1. The correct name of the game.
	2. The type of computer you are running the game on.
	3. Exact error message reported (if any).

For telephone technical support, please call (410) 568-2377. Support hours are from
8:00 a.m. to 12:00 midnight, Eastern Standard Time, Monday through Friday, and from
8:00 a.m. to 8:00 p.m., Eastern Standard Time, Saturday and Sunday, holidays excluded.
No game hints will be given through this number.

You may also communicate with our technical support via the Internet at:
	http://support.hasbro.com

This site contains an up-to-date interactive knowledge base and email contacts for
technical support.


To find out more about the Frogger2 CD-ROM game, please visit:
	http://www.frogger.com


For information about any other Hasbro Interactive product, please visit our main
web site at:
	http://www.hasbro-interactive.com


For more information on playing Frogger2 online, please visit Hasbro Interactive�s
Online Games area at:
	http:// www.games.com


For further information on the developers, Blitz Games, visit their web site at:
	http://www.blitzgames.com


Hasbro Interactive makes no representations regarding the content of any non-Hasbro
Interactive web sites. Non-Hasbro Interactive web sites are independent from Hasbro
Interactive and Hasbro Interactive has no control over content. A link to a non-Hasbro
Interactive web site does not mean that Hasbro Interactive endorses or accepts any
responsibility for the content or use of such a web site.


10. LICENSE AGREEMENT
*********************


***  IMPORTANT  ***

This is a legal agreement between the end user ("You") and Hasbro Interactive, Inc., its affiliates and subsidiaries (collectively "Hasbro Interactive").  This Agreement is part of a package (the "Package") that also includes, as applicable, executable files that you may download, a game cartridge or disc, or a CD-ROM (collectively referred to herein as the "Software") and certain written materials (the "Documentation"). Any patch, update, upgrade, modification or other enhancement provided by Hasbro Interactive with respect to the Software or the Documentation, or bonus game provided by Hasbro Interactive at no extra charge as part of the Package, shall be included within the meanings of those terms, for the purposes of this Agreement, except to the extent expressly provided below.

BY DOWNLOADING OR INSTALLING THE SOFTWARE, YOU ACKNOWLEDGE THAT YOU HAVE READ ALL OF THE TERMS AND CONDITIONS OF THIS AGREEMENT, UNDERSTAND THEM, AND AGREE TO BE BOUND BY THEM.  YOU UNDERSTAND THAT, IF YOU PURCHASED THE PACKAGE FROM AN AUTHORIZED RESELLER OF HASBRO INTERACTIVE, THAT RESELLER IS NOT HASBRO INTERACTIVE'S AGENT AND IS NOT AUTHORIZED TO MAKE ANY REPRESENTATIONS, CONDITIONS OR WARRANTIES, STATUTORY OR OTHERWISE, ON HASBRO INTERACTIVE'S BEHALF NOR TO VARY ANY OF THE TERMS OR CONDITIONS OF THIS AGREEMENT. 

If You do not agree to the terms of this Agreement, do not download or install the Software and promptly return the entire Package to the place You obtained it for a full refund.  If you should have any difficulty in obtaining such refund, please contact Hasbro Interactive at 800-683-5847 from the United States or at +44-1454 893-900 from outside the United States.

 CONSUMER SAFETY WARNINGS AND PRECAUTIONS STATEMENT:


Epilepsy Warning


WARNING


READ THIS NOTICE BEFORE YOU OR YOUR CHILD 
	USE THIS SOFTWARE

 A very small portion of the population have a condition which may cause them to experience epileptic seizures or have momentary loss of consciousness when viewing certain kinds of flashing lights or patterns.  These persons may experience seizures while watching some kinds of television pictures or playing certain video games.  Certain conditions may induce previously undetected epileptic symptoms even in persons who have no history of prior seizures or epilepsy.  
If you or anyone in your family has an epileptic condition or has experienced symptoms like an epileptic condition (e.g. a seizure or loss of awareness), immediately consult your physician before using this Software.

We recommend that parents observe their children while they play games.  If you or your child experience any of the following symptoms: dizziness, altered vision, eye or muscle twitching, involuntary movements, loss of awareness, disorientation, or convulsions, DISCONTINUE USE IMMEDIATELY and consult your physician.

FOLLOW THESE PRECAUTIONS WHENEVER USING THIS SOFTWARE:

* Do not sit or stand too close to the monitor. Play as far back from the monitor as possible.
* Do not play if you are tired or need sleep.
* Always play in a well lit room.
* Be sure to take a 10 to 15 minute break every hour while playing.


Repetitive Strain Statement

	CAUTION



Some people may experience fatigue or discomfort after playing for a long time.  Regardless of how you feel, you should ALWAYS take a 10 to 15 minute break every hour while playing.  If your hands or arms become tired or uncomfortable while playing, stop and rest.  If you continue to experience soreness or discomfort during or after play, listen to the signals your body is giving you.  Stop playing and consult a doctor.  Failure to do so could result in long term injury.

If your hands, wrist or arms have been injured or strained in other activities, use of this Software could aggravate the condition.  Before playing, consult a doctor.


Motion Sickness Statement


	CAUTION


This Software generates realistic images and 3-D simulations.  While playing or watching certain video images, some people may experience dizziness, motion sickness or nausea.  If you or your child experience any of these symptoms, discontinue use and play again later.


LIMITED LICENSE: You are entitled to download or install, and operate this Software solely for your own personal use, but may not sell or transfer reproductions of the Software or Documentation to other parties in any way.  You may download or install, and operate one copy of the Software on a single terminal connected to a single computer.  You may not network the Software or otherwise use it on more than one computer or computer terminal at the same time. 

 INTERNET-BASED PLAY; CHAT:  This Software may include Internet-play features.  If You choose to use such features, You will need to access the Internet.  The Software or Documentation may also suggest links to certain Software-related web sites, including web sites operated by Hasbro Interactive or third parties.  Your access to web sites operated by Hasbro Interactive is subject to the terms of use and privacy policies of such web sites.  Children should check with a parent or guardian before accessing the Internet, including without limitation any chat function, on-line "arcade," or em@il Game.  Internet game play may occur through one or more independent gaming or other web sites (each a "Web Site"), including without limitation the MSN Gaming Zone run by the Microsoft Corporation.  Hasbro Interactive does not review or control, and disclaims any responsibility or liability for, the functioning and performance of any Web Site, the terms of use of any Web Site, the privacy policies of any Web Site, and any content on or available via a Web Site, including, without limitation, links to other web sites and comments or other contact between users of a Web Site.  Hasbro Interactive does not endorse the Web Sites merely because a link to the Web Site is suggested or established.  Hasbro Interactive does not monitor, control, endorse, or accept responsibility for the content of text or voice chat messages, if applicable, transmitted through the use of the Software.  Use of the chat function, or other content or services of any Web Site is at Your own risk.  You are strongly encouraged not to give out identity or other personal information through chat transmissions.

 OWNERSHIP; COPYRIGHT:  Title to the Software and the Documentation, and patents, copyrights and all other property rights applicable thereto, shall at all times remain solely and exclusively with Hasbro Interactive and its licensors, and You shall not take any action inconsistent with such title. The Software and the Documentation are protected by United States, Canadian and other applicable laws and by international treaty provisions.  Any rights not expressly granted herein are reserved to Hasbro Interactive and its licensors. 
 
OTHER RESTRICTIONS:  You may not cause or permit the disclosure, copying, renting, licensing, sublicensing, leasing, dissemination or other distribution of the Software or the Documentation by any means or in any form, without the prior written consent of Hasbro Interactive.  You may not modify, enhance, supplement, create derivative work from, adapt, translate, reverse engineer, decompile, disassemble or otherwise reduce the Software to human readable form.  

LIMITED WARRANTY:

Hasbro Interactive warrants for a period of ninety (90) days following original retail purchase of this copy of the Software that the Software is free from substantial errors or defects that will materially interfere with the operation of the Software as described in the Documentation.  This limited warranty:  (i) applies to the initial purchaser only and may be acted upon only by the initial purchaser; and (ii) does not apply to any patch, update, upgrade, modification, or other enhancement provided by Hasbro Interactive with respect to the Software or the Documentation or to any bonus game provided by Hasbro Interactive at no extra charge as part of the Package, which are provided on an AS IS BASIS ONLY.  EXCEPT AS STATED ABOVE, HASBRO INTERACTIVE AND ITS LICENSORS MAKE NO OTHER WARRANTY OR CONDITION, EXPRESS OR IMPLIED, STATUTORY OR OTHERWISE, REGARDING THIS SOFTWARE.  THE IMPLIED WARRANTY THAT THE SOFTWARE IS FIT FOR A PARTICULAR PURPOSE AND THE IMPLIED WARRANTY OF MERCHANTABILITY SHALL BOTH BE LIMITED TO THE NINETY (90) DAY DURATION OF THIS LIMITED EXPRESS WARRANTY.  THESE AND ANY OTHER IMPLIED WARRANTIES OR CONDITIONS, STATUTORY OR OTHERWISE, ARE OTHERWISE EXPRESSLY AND SPECIFICALLY DISCLAIMED.  Some jurisdictions do not allow limitations on how long an implied warranty or condition lasts, so the above limitation may not apply to You.  This limited warranty gives You specific legal rights, and you may also have other rights which vary from jurisdiction to jurisdiction. 

If you believe you have found any such error or defect in the Software during the warranty period, (i) if you are in the United States, call Hasbro Interactive's Consumer Affairs Department at 800-683-5847 between the hours of 8:00 a.m. and 4:45 p.m Monday through Friday (Eastern Time), holidays excluded, and provide your Product number; or (ii) if you are outside the United States, send your original CD-ROM disc, game cartridge or disc, or, if applicable, the executable files that you downloaded, to Hasbro Interactive at Caswell Way, Newport, Gwent, NP9 0YH, United Kingdom, together with a dated proof of purchase, your Product number, a brief description of such error or defect and the address to which the Software is to be returned.  If you have a problem resulting from a manufacturing defect in the Software, Hasbro Interactive's and its licensors' entire liability and Your exclusive remedy for breach of this limited warranty shall be the replacement of the Software, within a reasonable period of time and without charge, with a corrected version of the Software.  Some jurisdictions do not allow the exclusion or limitation of relief, incidental or consequential damages, so the above limitation or exclusion may not apply to You.

LIMITATION OF LIABILITY

HASBRO INTERACTIVE AND ITS LICENSORS SHALL NOT BE LIABLE FOR SPECIAL, INCIDENTAL, CONSEQUENTIAL, EXEMPLARY OR OTHER INDIRECT DAMAGES, EVEN IF HASBRO INTERACTIVE OR ITS LICENSORS ARE ADVISED OF OR AWARE OF THE POSSIBILITY OF SUCH DAMAGES.  IN NO EVENT SHALL HASBRO INTERACTIVE'S AND ITS LICENSORS' AGGREGATE LIABILITY EXCEED THE PURCHASE PRICE OF THIS PACKAGE.  Some jurisdictions do not allow the exclusion or limitation of special, incidental, consequential, indirect or exemplary damages, or the limitation of liability to specified amounts, so the above limitation or exclusion may not apply to You.

GENERAL:  This Agreement constitutes the entire understanding between Hasbro Interactive and You with respect to subject matter hereof.  Any change to this Agreement must be in writing, signed by Hasbro Interactive and You.  Terms and conditions as set forth in any purchase order which differ from, conflict with, or are not included in this Agreement, shall not become part of this Agreement unless specifically accepted by Hasbro Interactive in writing.  You shall be responsible for and shall pay, and shall reimburse Hasbro Interactive on request if Hasbro Interactive is required to pay, any sales, use, value added (VAT), consumption or other tax (excluding any tax that is based on Hasbro Interactive's net income), assessment, duty, tariff, or other fee or charge of any kind or nature that is levied or imposed by any governmental authority on the Package.
  EXPORT AND IMPORT COMPLIANCE:  In the event You export the Software or the Documentation from the country in which You first received it, You assume the responsibility for compliance with all applicable export and re-export regulations, as the case may be. 

 GOVERNING LAW; ARBITRATION:  This Agreement shall be governed by, and any arbitration hereunder shall apply, the laws of the Commonwealth of Massachusetts, U.S.A., excluding (a) its conflicts of laws principles; (b) the United Nations Convention on Contracts for the International Sale of Goods; (c) the 1974 Convention on the Limitation Period in the International Sale of Goods (the "1974 Convention"); and (d) the Protocol amending the 1974 Convention, done at Vienna April 11, 1980.  

Any dispute, controversy or claim arising out of or relating to this Agreement or to a breach hereof, including its interpretation, performance or termination, shall be finally resolved by arbitration.  The arbitration shall be conducted by three (3) arbitrators, one to be appointed by Hasbro Interactive, one to be appointed by You and a third being nominated by the two arbitrators so selected or, if they cannot agree on a third arbitrator, by the President of the American Arbitration Association ("AAA").  The arbitration shall be conducted in English and in accordance with the commercial arbitration rules of the AAA.  The arbitration, including the rendering of the award, shall take place in Boston, Massachusetts, and shall be the exclusive forum for resolving such dispute, controversy or claim.  The decision of the arbitrators shall be binding upon the parties hereto, and the expense of the arbitration (including without limitation the award of attorneys' fees to the prevailing party) shall be paid as the arbitrators determine.  The decision of the arbitrators shall be executory, and judgment thereon may be entered by any court of competent jurisdiction.

Notwithstanding anything contained in the foregoing Paragraph to the contrary, Hasbro Interactive shall have the right to institute judicial proceedings against You or anyone acting by, through or under You, in order to enforce Hasbro Interactive's rights hereunder through reformation of contract, specific performance, injunction or similar equitable relief.  For the purposes of this Paragraph, both parties submit to the jurisdiction of, and waive any objection to the venue of, the state and federal courts of the Commonwealth of Massachusetts.



